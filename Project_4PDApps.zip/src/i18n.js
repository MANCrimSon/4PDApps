// Localization module for 4PDApps: Russian (ru), Ukrainian (uk), Belarusian (be), English (en), German (de)

export const LANGUAGES = [
  { id: "ru", name: "Русский", sub: "По умолчанию" },
  { id: "uk", name: "Українська", sub: "Українська мова" },
  { id: "be", name: "Беларуская", sub: "Беларуская мова" },
  { id: "en", name: "English", sub: "English language" },
  { id: "de", name: "Deutsch", sub: "Deutsche Sprache" },
];

export function getLang() {
  try {
    const l = localStorage.getItem("t4_lang") || "ru";
    return ["ru", "uk", "be", "en", "de"].includes(l) ? l : "ru";
  } catch {
    return "ru";
  }
}

export function getLangName(id) {
  const code = id || getLang();
  const found = LANGUAGES.find((x) => x.id === code);
  return found ? found.name : "Русский";
}

// Dictionary of UI phrases mapped from Russian -> [uk, be, en, de]
const PHRASES = {
  // Tabs & Navigation
  "ИЗБРАННОЕ": ["ОБРАНЕ", "АБРАНАЕ", "FAVORITES", "FAVORITEN"],
  "ПРИЛОЖЕНИЯ": ["ПРОГРАМИ", "ПРАГРАМЫ", "APPS", "APPS"],
  "ИГРЫ": ["ІГРИ", "ГУЛЬНІ", "GAMES", "SPIELE"],
  "ЭМУЛЯТОРЫ": ["ЕМУЛЯТОРИ", "ЭМУЛЯТАРЫ", "EMULATORS", "EMULATOREN"],
  "НЕ СВЯЗАННЫЕ": ["НЕ ПОВ'ЯЗАНІ", "НЕ ЗВЯЗАНЫЯ", "UNLINKED", "NICHT VERKNÜPFT"],
  "Избранное": ["Обране", "Абранае", "Favorites", "Favoriten"],
  "Программы": ["Програми", "Праграмы", "Apps", "Programme"],
  "Игры": ["Ігри", "Гульні", "Games", "Spiele"],
  "Эмуляторы": ["Емулятори", "Эмулятары", "Emulators", "Emulatoren"],
  "Не связанные": ["Не пов'язані", "Не звязаныя", "Unlinked", "Nicht verknüpft"],
  "Системные": ["Системні", "Сістэмныя", "System apps", "System-Apps"],
  "Скрытые": ["Приховані", "Схаваныя", "Hidden", "Ausgeblendet"],
  "Загрузки": ["Завантаження", "Спампоўкі", "Downloads", "Downloads"],
  "Поиск": ["Пошук", "Пошук", "Search", "Suche"],
  "Обновить": ["Оновити", "Абнавіць", "Refresh", "Aktualisieren"],
  "Обновления": ["Оновлення", "Абнаўленні", "Updates", "Updates"],
  "ОБНОВЛЕНИЯ": ["ОНОВЛЕННЯ", "АБНАЎЛЕННІ", "UPDATES", "UPDATES"],
  "ФАЙЛЫ": ["ФАЙЛИ", "ФАЙЛЫ", "FILES", "DATEIEN"],
  "Файлы": ["Файли", "Файлы", "Files", "Dateien"],
  "Доступные обновления": ["Доступні оновлення", "Даступныя абнаўленні", "Available updates", "Verfügbare Updates"],

  // Common Buttons & States
  "ОК": ["ОК", "ОК", "OK", "OK"],
  "ДА": ["ТАК", "ТАК", "YES", "JA"],
  "Да": ["Так", "Так", "Yes", "Ja"],
  "да": ["так", "так", "yes", "ja"],
  "НЕТ": ["НІ", "НЕ", "NO", "NEIN"],
  "нет": ["ні", "не", "no", "nein"],
  "ОТМЕНА": ["СКАСУВАТИ", "СКАСАВАЦЬ", "CANCEL", "ABBRECHEN"],
  "Отмена": ["Скасувати", "Скасаваць", "Cancel", "Abbrechen"],
  "ЗАКРЫТЬ": ["ЗАКРИТИ", "ЗАКРЫЦЬ", "CLOSE", "SCHLIESSEN"],
  "СОХРАНИТЬ": ["ЗБЕРЕГТИ", "ЗАХАВАЦЬ", "SAVE", "SPEICHERN"],
  "Сохранить": ["Зберегти", "Захаваць", "Save", "Speichern"],
  "СКАЧАТЬ": ["ЗАВАНТАЖИТИ", "СПАМПАВАЦЬ", "DOWNLOAD", "HERUNTERLADEN"],
  "Скачать": ["Завантажити", "Спампаваць", "Download", "Herunterladen"],
  "ВОССТАНОВИТЬ": ["ВІДНОВИТИ", "АДНАВІЦЬ", "RESTORE", "WIEDERHERSTELLEN"],
  "Восстановить": ["Відновити", "Аднавіць", "Restore", "Wiederherstellen"],
  "Изменить": ["Змінити", "Змяніць", "Change", "Ändern"],
  "Повторить": ["Повторити", "Паўтарыць", "Retry", "Wiederholen"],
  "Позже": ["Пізніше", "Пазней", "Later", "Später"],
  "Удалить": ["Видалити", "Выдаліць", "Delete", "Löschen"],
  "Очистить": ["Очистити", "Ачысціць", "Clear", "Leeren"],
  "Скрыть": ["Приховати", "Схаваць", "Hide", "Ausblenden"],
  "Загрузка…": ["Завантаження…", "Загрузка…", "Loading…", "Laden…"],
  "Ожидание…": ["Очікування…", "Чаканне…", "Waiting…", "Warten…"],
  "Пусто": ["Порожньо", "Пуста", "Empty", "Leer"],
  "пусто": ["порожньо", "пуста", "empty", "leer"],
  "Ошибка": ["Помилка", "Памылка", "Error", "Fehler"],
  "ошибка": ["помилка", "памылка", "error", "fehler"],
  "ошибка:": ["помилка:", "памылка:", "error:", "Fehler:"],
  "Скопировано": ["Скопійовано", "Скапіявана", "Copied", "Kopiert"],
  "Не удалось скопировать": ["Не вдалося скопіювати", "Не ўдалося скапіяваць", "Failed to copy", "Kopieren fehlgeschlagen"],
  "Не удалось сохранить": ["Не вдалося зберегти", "Не ўдалося захаваць", "Failed to save", "Speichern fehlgeschlagen"],
  "Выбрано:": ["Вибрано:", "Выбрана:", "Selected:", "Ausgewählt:"],
  "Показать ещё (": ["Показати ще (", "Паказаць яшчэ (", "Show more (", "Mehr anzeigen ("],

  // Empty States
  "В избранном пусто": ["В обраному порожньо", "У абраным пуста", "No favorites yet", "Keine Favoriten vorhanden"],
  "Все приложения связаны с 4pda": ["Усі програми пов'язані з 4pda", "Усе праграмы звязаны з 4pda", "All apps are linked to 4PDA", "Alle Apps sind mit 4PDA verknüpft"],
  "Игры не найдены": ["Ігри не знайдено", "Гульні не знойдзены", "No games found", "Keine Spiele gefunden"],
  "Эмуляторы не найдены": ["Емулятори не знайдено", "Эмулятары не знойдзены", "No emulators found", "Keine Emulatoren gefunden"],
  "Приложения не найдены": ["Програми не знайдено", "Праграмы не знойдзены", "No apps found", "Keine Apps gefunden"],
  "Ничего не найдено": ["Нічого не знайдено", "Нічога не знойдзена", "Nothing found", "Nichts gefunden"],

  // Sorting & Filtering
  "Сортировка": ["Сортування", "Сартаванне", "Sort", "Sortierung"],
  "Сортировка списка": ["Сортування списку", "Сартаванне спісу", "Sort list", "Liste sortieren"],
  "По дате обновления": ["За датою оновлення", "Па даце абнаўлення", "By update date", "Nach Aktualisierungsdatum"],
  "По имени": ["За назвою", "Па назве", "By name", "Nach Name"],
  "По версии": ["За версією", "Па версіі", "By version", "Nach Version"],
  "По размеру": ["За розміром", "Па памеры", "By size", "Nach Größe"],
  "По дате установки": ["За датою встановлення", "Па даце ўстаноўкі", "By install date", "Nach Installationsdatum"],
  "Сначала с обновлениями": ["Спочатку з оновленнями", "Спачатку з абнаўленнямі", "Updates first", "Updates zuerst"],
  "По совпадению": ["За збігом", "Па супадзенні", "By relevance", "Nach Relevanz"],
  "По установкам": ["За встановленнями", "Па ўстаноўках", "By installs", "Nach Installationen"],
  "По скачиванию": ["За завантаженнями", "Па спампоўках", "By downloads", "Nach Downloads"],

  // Context Menu
  "Открыть приложение": ["Відкрити програму", "Адкрыць праграму", "Open app", "App öffnen"],
  "Доступные связи (связать тему)": ["Доступні зв'язки (пов'язати тему)", "Даступныя сувязі (звязаць тэму)", "Link 4PDA topic", "4PDA-Thema verknüpfen"],
  "Сделать видимым": ["Зробити видимим", "Зрабіць бачным", "Unhide app", "Einblenden"],
  "Скрыть приложение": ["Приховати програму", "Схаваць праграму", "Hide app", "App ausblenden"],
  "Скрыть все обновления": ["Приховати всі оновлення", "Схаваць усе абнаўленні", "Hide all updates", "Alle Updates ausblenden"],
  "Скрыть обновления с форума": ["Приховати оновлення з форуму", "Схаваць абнаўленні з форуму", "Hide forum updates", "Forum-Updates ausblenden"],
  "Скрыть обновления с Google Play": ["Приховати оновлення з Google Play", "Схаваць абнаўленні з Google Play", "Hide Google Play updates", "Google Play-Updates ausblenden"],
  "Информация": ["Інформація", "Інфармацыя", "App info", "App-Info"],

  // App Info Dialog
  "Имя пакета": ["Ім'я пакета", "Імя пакета", "Package name", "Paketname"],
  "Имя пакета:": ["Ім'я пакета:", "Імя пакета:", "Package name:", "Paketname:"],
  "Имя приложения": ["Назва програми", "Назва праграмы", "App name", "App-Name"],
  "Имя на форуме": ["Назва на форумі", "Назва на форуме", "Forum title", "Forum-Titel"],
  "Версия (код)": ["Версія (код)", "Версія (код)", "Version (code)", "Version (Code)"],
  "Версия на форуме": ["Версія на форумі", "Версія на форуме", "Forum version", "Forum-Version"],
  "Версия в Google Play": ["Версія в Google Play", "Версія ў Google Play", "Google Play version", "Google Play-Version"],
  "Дата на форуме": ["Дата на форумі", "Дата на форуме", "Forum date", "Forum-Datum"],
  "Обновление шапки": ["Оновлення шапки", "Абнаўленне шапкі", "Header updated", "Kopfzeile aktualisiert"],
  "Дата обновления": ["Дата оновлення", "Дата абнаўлення", "Last updated", "Aktualisiert am"],
  "Дата установки": ["Дата встановлення", "Дата ўстаноўкі", "Installed on", "Installiert am"],
  "Размер APK": ["Розмір APK", "Памер APK", "APK size", "APK-Größe"],
  "Установщик": ["Встановлювач", "Устаноўшчык", "Installer", "Installer"],
  "Связь": ["Зв'язок", "Сувязь", "Topic ID", "Themen-ID"],

  // Downloads & Installation
  "Нет загрузок": ["Немає завантажень", "Няма спамповак", "No downloads", "Keine Downloads"],
  "Пауза": ["Пауза", "Паўза", "Pause", "Pause"],
  "Возобновить": ["Продовжити", "Аднавіць", "Resume", "Fortsetzen"],
  "Готово — нажми, чтобы установить": ["Готово — натисни, щоб встановити", "Гатова — націсні, каб усталяваць", "Done — tap to install", "Fertig — zum Installieren tippen"],
  "Очистить загрузки?": ["Очистити завантаження?", "Ачысціць спампоўкі?", "Clear downloads?", "Downloads leeren?"],
  "ТОЛЬКО СПИСОК": ["ЛИШЕ СПИСОК", "ТОЛЬКІ СПІС", "LIST ONLY", "NUR LISTE"],
  "ВМЕСТЕ С ФАЙЛАМИ": ["РАЗОМ ІЗ ФАЙЛАМИ", "РАЗАМ З ФАЙЛАМІ", "WITH FILES", "MIT DATEIEN"],
  "Удалить загрузку": ["Видалити завантаження", "Выдаліць спампоўку", "Delete download", "Download löschen"],
  "Удалить файл и задачу": ["Видалити файл і завдання", "Выдаліць файл і задачу", "Delete file and task", "Datei und Aufgabe löschen"],
  "Убрать из списка (файл оставить)": ["Прибрати зі списку (файл залишити)", "Прыбраць са спісу (файл пакінуць)", "Remove from list (keep file)", "Aus Liste entfernen (Datei behalten)"],
  "Подпись не совпадает": ["Підпис не збігається", "Подпіс не супадае", "Signature mismatch", "Signatur stimmt nicht überein"],
  "Подпись у этого файла не совпадает с подписью установленной у вас версии. Перед установкой нужно удалить установленную программу.": [
    "Підпис цього файлу не збігається з підписом встановленої у вас версії. Перед встановленням потрібно видалити встановлену програму.",
    "Подпіс гэтага файла не супадае з подпісам усталяванай у вас версіі. Перад устаноўкай трэба выдаліць усталяваную праграму.",
    "This file's signature does not match the installed version. You need to uninstall the current app before installing.",
    "Die Signatur dieser Datei stimmt nicht mit der installierten Version überein. Bitte deinstallieren Sie zuerst die vorhandene App."
  ],
  "Подпись у этого файла не совпадает с подписью установленной у вас версии программы. Перед установкой этого файла нужно будет удалить установленную программу.": [
    "Підпис цього файлу не збігається з підписом встановленої у вас версії програми. Перед встановленням цього файлу потрібно буде видалити встановлену програму.",
    "Подпіс гэтага файла не супадае з подпісам усталяванай у вас версіі праграмы. Перад устаноўкай гэтага файла трэба будзе выдаліць усталяваную праграму.",
    "This file's signature does not match the installed app version. You will need to uninstall the current app before installing this file.",
    "Die Signatur dieser Datei stimmt nicht mit der installierten App-Version überein. Vor der Installation muss die installierte App deinstalliert werden."
  ],
  "Удалить установленную": ["Видалити встановлену", "Выдаліць усталяваную", "Uninstall current", "Installierte deinstallieren"],
  "Всё равно установить": ["Все одно встановити", "Усё роўна ўсталяваць", "Install anyway", "Trotzdem installieren"],
  "Начать закачку?": ["Почати завантаження?", "Пачаць спампоўку?", "Start download?", "Download starten?"],
  "Загрузка началась": ["Завантаження почалося", "Спампоўка пачалася", "Download started", "Download gestartet"],
  "Открыть загрузки?": ["Відкрити завантаження?", "Адкрыць спампоўкі?", "Open downloads?", "Downloads öffnen?"],

  // Files & Topic View
  "Все файлы": ["Усі файли", "Усе файлы", "All files", "Alle Dateien"],
  "Другая подпись": ["Інший підпис", "Іншы подпіс", "Different signature", "Andere Signatur"],
  "Архивы": ["Архіви", "Архівы", "Archives", "Archive"],
  "Подгружаю файлы из темы, подожди…": ["Підвантажую файли з теми, зачекай…", "Падгружаю файлы з тэмы, пачакай…", "Loading files from topic, please wait…", "Dateien aus dem Thema werden geladen…"],
  "Подгружаю ещё файлы из темы…": ["Підвантажую ще файли з теми…", "Падгружаю яшчэ файлы з тэмы…", "Loading more files from topic…", "Weitere Dateien werden geladen…"],
  "Более новых версий не найдено.": ["Новіших версій не знайдено.", "Больш новых версій не знойдзена.", "No newer versions found.", "Keine neueren Versionen gefunden."],
  "Файлы в теме не найдены.": ["Файли в темі не знайдено.", "Файлы ў тэме не знойдзены.", "No files found in topic.", "Keine Dateien im Thema gefunden."],
  "Название": ["Назва", "Назва", "Name", "Name"],
  "Имя файла:": ["Ім'я файлу:", "Імя файла:", "File name:", "Dateiname:"],
  "Версия": ["Версія", "Версія", "Version", "Version"],
  "Версия:": ["Версія:", "Версія:", "Version:", "Version:"],
  "Размер": ["Розмір", "Памер", "Size", "Größe"],
  "Подпись:": ["Підпис:", "Подпіс:", "Signature:", "Signatur:"],
  "Требования:": ["Вимоги:", "Патрабаванні:", "Requirements:", "Anforderungen:"],
  "Скачиваний:": ["Завантажень:", "Спамповак:", "Downloads:", "Downloads:"],
  "Добавлено:": ["Додано:", "Дададзена:", "Added:", "Hinzugefügt:"],
  "· совпадает с вашей": ["· збігається з вашою", "· супадае з вашай", "· matches installed", "· stimmt überein"],
  "· отличается от вашей": ["· відрізняється від вашої", "· адрозніваецца ад вашай", "· differs from installed", "· weicht ab"],
  "· другое приложение": ["· інша програма", "· іншая праграма", "· different app", "· andere App"],
  "Отдельное приложение — подпись сравнивать не с чем.": [
    "Окрема програма — підпис немає з чим порівнювати.",
    "Асобная праграма — подпіс няма з чым параўноўваць.",
    "Separate app — no installed signature to compare.",
    "Separate App — keine installierte Signatur zum Vergleich."
  ],
  "Подпись совпадает с установленной версией.": [
    "Підпис збігається зі встановленою версією.",
    "Подпіс супадае з усталяванай версіяй.",
    "Signature matches the installed version.",
    "Signatur stimmt mit der installierten Version überein."
  ],
  "Подпись не совпадает с установленной — перед установкой придётся удалить программу.": [
    "Підпис не збігається зі встановленою — перед встановленням доведеться видалити програму.",
    "Подпіс не супадае з усталяванай — перад устаноўкай давядзецца выдаліць праграму.",
    "Signature mismatch — you must uninstall the current app before installing.",
    "Signatur weicht ab — die installierte App muss vorher deinstalliert werden."
  ],
  "Этот файл предназначен для другого типа процессора, на вашем устройстве он не заработает.": [
    "Цей файл призначений для іншого типу процесора, на вашому пристрої він не запрацює.",
    "Гэты файл прызначаны для іншага тыпу працэсара, на вашай прыладзе ён не запрацуе.",
    "This file is built for a different CPU architecture and will not work on your device.",
    "Diese Datei ist für eine andere Prozessorarchitektur bestimmt und funktioniert auf Ihrem Gerät nicht."
  ],
  "не для вашего процессора": ["не для вашого процесора", "не для вашага працэсара", "incompatible CPU", "inkompatible CPU"],
  "Загружаю сведения…": ["Завантажую відомості…", "Загружаю звесткі…", "Loading details…", "Details werden geladen…"],
  "Нет сведений на сервере": ["Немає відомостей на сервері", "Няма звестак на серверы", "No details on server", "Keine Details auf dem Server"],
  "Пост 4pda": ["Пост 4pda", "Пост 4pda", "4PDA Post", "4PDA-Beitrag"],
  "Открыть на 4pda": ["Відкрити на 4pda", "Адкрыць на 4pda", "Open on 4PDA", "Auf 4PDA öffnen"],
  "Открыть 4pda": ["Відкрити 4pda", "Адкрыць 4pda", "Open 4PDA", "4PDA öffnen"],
  "Искать на 4pda": ["Шукати на 4pda", "Шукаць на 4pda", "Search on 4PDA", "Auf 4PDA suchen"],
  "Загрузка темы с 4pda…": ["Завантаження теми з 4pda…", "Загрузка тэмы з 4pda…", "Loading topic from 4PDA…", "Thema von 4PDA wird geladen…"],
  "4pda просит проверку. Открой 4pda, войди/реши капчу и вернись.": [
    "4pda просить перевірку. Відкрий 4pda, увійди/пройди капчу і повернись.",
    "4pda просіць праверку. Адкрый 4pda, увайдзі/развяжы капчу і вярніся.",
    "4PDA requires verification. Open 4PDA, log in or solve captcha, and return.",
    "4PDA erfordert eine Überprüfung. Öffnen Sie 4PDA, melden Sie sich an / lösen Sie das Captcha und kehren Sie zurück."
  ],
  "Тема не загрузилась (4pda мог не ответить).": [
    "Тема не завантажилась (4pda міг не відповісти).",
    "Тэма не загрузілася (4pda мог не адказаць).",
    "Topic failed to load (4PDA did not respond).",
    "Thema konnte nicht geladen werden (keine Antwort von 4PDA)."
  ],
  "Обновление:": ["Оновлення:", "Абнаўленне:", "Updated:", "Aktualisiert:"],

  // Search & Linking
  "Поиск на сайте": ["Пошук на сайті", "Пошук на сайце", "Site search", "Website-Suche"],
  "Поиск на 4pda": ["Пошук на 4pda", "Пошук на 4pda", "Search on 4PDA", "Auf 4PDA suchen"],
  "Поиск темы на 4pda": ["Пошук теми на 4pda", "Пошук тэмы на 4pda", "Search topic on 4PDA", "Thema auf 4PDA suchen"],
  "Область поиска": ["Область пошуку", "Вобласць пошуку", "Search scope", "Suchbereich"],
  "Искать всё": ["Шукати все", "Шукаць усё", "Search everything", "Alles durchsuchen"],
  "Только по названию": ["Лише за назвою", "Толькі па назве", "Title only", "Nur im Titel"],
  "Только в описании": ["Лише в описі", "Толькі ў апісанні", "Description only", "Nur in Beschreibung"],
  "ВСЁ": ["ВСЕ", "УСЁ", "ALL", "ALLE"],
  "НАЗВ": ["НАЗВ", "НАЗВ", "TITLE", "TITEL"],
  "ОПИС": ["ОПИС", "АПІС", "DESC", "BESCHR"],
  "Введите запрос и нажмите поиск": ["Введіть запит і натисніть пошук", "Увядзіце запыт і націсніце пошук", "Enter a query and press search", "Suchbegriff eingeben und suchen"],
  "Ищу, подожди...": ["Шукаю, зачекай...", "Шукаю, пачакай...", "Searching, please wait...", "Suche läuft, bitte warten..."],
  "4pda просит капчу для поиска": ["4pda просить капчу для пошуку", "4pda просіць капчу для пошуку", "4PDA requires captcha for search", "4PDA erfordert ein Captcha für die Suche"],
  "Войдите в 4pda через меню (гамбургер) — тогда поиск не будет требовать капчу.": [
    "Увійдіть у 4pda через меню (гамбургер) — тоді пошук не вимагатиме капчу.",
    "Увайдзіце ў 4pda праз меню (гамбургер) — тады пошук не будзе патрабаваць капчу.",
    "Log in to 4PDA via the side menu — search won't require captcha after login.",
    "Melden Sie sich über das Menü bei 4PDA an — danach ist kein Captcha mehr nötig."
  ],
  "Попробуйте другой запрос.": ["Спробуйте інший запит.", "Паспрабуйце іншы запыт.", "Try a different query.", "Versuchen Sie eine andere Suchanfrage."],
  "Каталог 4pda для поиска по части названия ещё не загружен с GitHub. Он подкачается сам — подожди немного, перезапусти приложение или нажми «Обновить каталог» в настройках.": [
    "Каталог 4pda для пошуку за частиною назви ще не завантажений з GitHub. Він підвантажиться сам — зачекай трохи, перезапусти програму або натисни «Оновити каталог» у налаштуваннях.",
    "Каталог 4pda для пошуку па частцы назвы яшчэ не загружаны з GitHub. Ён падпампуецца сам — пачакай крыху, перазапусці праграму або націсні «Абнавіць каталог» у наладах.",
    "The 4PDA catalog for substring search hasn't finished downloading from GitHub yet. Wait a moment, restart the app, or tap 'Update catalog' in Settings.",
    "Der 4PDA-Katalog für die Teilwortsuche wurde noch nicht von GitHub geladen. Bitte kurz warten, App neu starten oder in den Einstellungen auf „Katalog aktualisieren“ tippen."
  ],
  "Связать тему": ["Пов'язати тему", "Звязаць тэму", "Link topic", "Thema verknüpfen"],
  "Связать тему?": ["Пов'язати тему?", "Звязаць тэму?", "Link topic?", "Thema verknüpfen?"],
  "Связать по ссылке": ["Пов'язати за посиланням", "Звязаць па спасылцы", "Link by URL", "Per Link verknüpfen"],
  "Ссылка на тему 4pda или её номер": ["Посилання на тему 4pda або її номер", "Спасылка на тэму 4pda або яе нумар", "4PDA topic URL or topic ID", "4PDA-Themenlink oder Themen-ID"],
  "Тема по ссылке": ["Тема за посиланням", "Тэма па спасылцы", "Topic by link", "Thema per Link"],
  "Связать": ["Пов'язати", "Звязаць", "Link", "Verknüpfen"],
  "Связывание…": ["Пов'язування…", "Звязванне…", "Linking…", "Verknüpfen…"],
  "· тема": ["· тема", "· тэма", "· topic", "· Thema"],

  // Drawer & Auth
  "вы авторизованы": ["ви авторизовані", "вы аўтарызаваны", "logged in", "angemeldet"],
  "Выйти из 4pda": ["Вийти з 4pda", "Выйсці з 4pda", "Log out of 4PDA", "Von 4PDA abmelden"],
  "Выхожу…": ["Виходжу…", "Выходжу…", "Logging out…", "Abmelden…"],
  "Войти в 4pda": ["Увійти в 4pda", "Увайсці ў 4pda", "Log in to 4PDA", "Bei 4PDA anmelden"],
  "Вход в 4pda": ["Вхід у 4pda", "Уваход у 4pda", "4PDA Login", "4PDA-Anmeldung"],
  "Логин или e-mail": ["Логін або e-mail", "Лагін або e-mail", "Username or email", "Benutzername oder E-Mail"],
  "Пароль": ["Пароль", "Пароль", "Password", "Passwort"],
  "Скрытый вход (невидимка)": ["Прихований вхід (невидимка)", "Схаваны ўваход (невідзімка)", "Invisible login (stealth)", "Unsichtbare Anmeldung"],
  "Введите текст с картинки": ["Введіть текст із картинки", "Увядзіце тэкст з малюнка", "Enter captcha text", "Text aus dem Bild eingeben"],
  "Введите капчу с картинки": ["Введіть капчу з картинки", "Увядзіце капчу з малюнка", "Enter image captcha", "Bild-Captcha eingeben"],
  "Неверная капча — введите новую": ["Невірна капча — введіть нову", "Няправільная капча — увядзіце новую", "Invalid captcha — try again", "Falsches Captcha — bitte neu eingeben"],
  "Проверьте логин, пароль и капчу": ["Перевірте логін, пароль і капчу", "Праверце лагін, пароль і капчу", "Check username, password, and captcha", "Benutzername, Passwort und Captcha prüfen"],
  "Неверный логин или пароль": ["Невірний логін або пароль", "Няправільны лагін або пароль", "Invalid username or password", "Falscher Benutzername oder Passwort"],
  "Ошибка входа": ["Помилка входу", "Памылка ўваходу", "Login error", "Anmeldefehler"],
  "Капча не загрузилась (Cloudflare). Закрой и открой вход ещё раз.": [
    "Капча не завантажилась (Cloudflare). Закрий і відкрий вхід ще раз.",
    "Капча не загрузілася (Cloudflare). Закрый і адкрый уваход яшчэ раз.",
    "Captcha failed to load (Cloudflare). Close and reopen login.",
    "Captcha wurde nicht geladen (Cloudflare). Bitte schließen und erneut öffnen."
  ],
  "Cloudflare — открываю вход 4pda": ["Cloudflare — відкриваю вхід 4pda", "Cloudflare — адкрываю ўваход 4pda", "Cloudflare — opening 4PDA login", "Cloudflare — 4PDA-Login wird geöffnet"],
  "Cloudflare-проверка — открываю вход 4pda": ["Cloudflare-перевірка — відкриваю вхід 4pda", "Cloudflare-праверка — адкрываю ўваход 4pda", "Cloudflare check — opening 4PDA login", "Cloudflare-Prüfung — 4PDA-Login wird geöffnet"],
  "Войти": ["Увійти", "Увайсці", "Log in", "Anmelden"],
  "Вход…": ["Вхід…", "Уваход…", "Logging in…", "Anmelden…"],
  "После входа связь и поиск на 4pda работают стабильнее (проходит Cloudflare), а список обновится автоматически.": [
    "Після входу зв'язок і пошук на 4pda працюють стабільніше (проходить Cloudflare), а список оновиться автоматично.",
    "Пасля ўваходу сувязь і пошук на 4pda працуюць стабільней (праходзіць Cloudflare), а спіс абновіцца аўтаматычна.",
    "Logging in improves 4PDA search and linking stability (bypasses Cloudflare) and refreshes the list automatically.",
    "Nach der Anmeldung funktionieren Suche und Verknüpfung auf 4PDA stabiler (Cloudflare) und die Liste wird automatisch aktualisiert."
  ],
  "сборка": ["збірка", "зборка", "build", "Build"],

  // Settings & Themes
  "Настройки": ["Налаштування", "Налады", "Settings", "Einstellungen"],
  "Язык": ["Мова", "Мова", "Language", "Sprache"],
  "Язык интерфейса": ["Мова інтерфейсу", "Мова інтэрфейсу", "Interface language", "Oberflächensprache"],
  "Тема": ["Тема", "Тэма", "Theme", "Design"],
  "Системная": ["Системна", "Сістэмная", "System", "System"],
  "Системная (как на телефоне)": ["Системна (як на телефоні)", "Сістэмная (як на тэлефоне)", "System default (follow device)", "Systemstandard (wie Gerät)"],
  "Тёмная": ["Темна", "Цёмная", "Dark", "Dunkel"],
  "Светлая": ["Світла", "Светлая", "Light", "Hell"],
  "Monet светлая": ["Monet світла", "Monet светлая", "Monet Light", "Monet Hell"],
  "Monet тёмная": ["Monet темна", "Monet цёмная", "Monet Dark", "Monet Dunkel"],
  "Вид": ["Вигляд", "Выгляд", "Appearance", "Darstellung"],
  "Крупные карточки": ["Великі картки", "Буйныя карткі", "Large cards", "Große Karten"],
  "Разделы": ["Розділи", "Раздзелы", "Sections", "Bereiche"],
  "Тип поиска": ["Тип пошуку", "Тып пошуку", "Search mode", "Suchmodus"],
  "Искать всё сразу (Программы, Игры, Эмуляторы во вкладках)": [
    "Шукати все одразу (Програми, Ігри, Емулятори у вкладках)",
    "Шукаць усё адразу (Праграмы, Гульні, Эмулятары ва ўкладках)",
    "Search all at once (Apps, Games, Emulators in tabs)",
    "Alles gleichzeitig suchen (Apps, Spiele, Emulatoren in Tabs)"
  ],
  "Папка скачивания": ["Папка завантаження", "Папка спампоўкі", "Download folder", "Download-Ordner"],
  "Папка «Загрузки»": ["Папка «Завантаження»", "Папка «Спампоўкі»", "Downloads folder", "Ordner „Downloads“"],
  "выбранная папка": ["вибрана папка", "выбраная папка", "selected folder", "ausgewählter Ordner"],
  "Сбросить на «Загрузки»": ["Скинути на «Завантаження»", "Скінуць на «Спампоўкі»", "Reset to Downloads", "Auf „Downloads“ zurücksetzen"],
  "Всегда спрашивать, куда сохранить": ["Завжди питати, куди зберегти", "Заўсёды пытаць, куды захаваць", "Always ask where to save", "Immer fragen, wo gespeichert werden soll"],
  "Не спрашивать подтверждение": ["Не питати підтвердження", "Не пытаць пацвярджэння", "Skip download confirmation", "Keine Bestätigung abfragen"],
  "Пропуск диалога «Начать закачку?» (скачивание в 1 клик)": [
    "Пропуск діалогу «Почати завантаження?» (завантаження в 1 клік)",
    "Пропуск дыялогу «Пачаць спампоўку?» (спампоўка ў 1 клік)",
    "Skip 'Start download?' dialog (1-tap download)",
    "Dialog „Download starten?“ überspringen (1-Klick-Download)"
  ],
  "Автоматическая установка": ["Автоматичне встановлення", "Аўтаматычная ўстаноўка", "Auto-install after download", "Automatische Installation"],
  "Запуск установки сразу после окончания загрузки": [
    "Запуск встановлення одразу після закінчення завантаження",
    "Запуск устаноўкі адразу пасля заканчэння спампоўкі",
    "Launch installer immediately when download finishes",
    "Installation sofort nach Abschluss des Downloads starten"
  ],
  "Способ установки APK": ["Спосіб встановлення APK", "Спосаб устаноўкі APK", "APK installer method", "APK-Installationsmethode"],
  "Стандартный установщик": ["Стандартний встановлювач", "Стандартны ўстаноўшчык", "System installer", "Standard-Paketinstaller"],
  "Системный установщик Android (по умолчанию)": [
    "Системний встановлювач Android (за замовчуванням)",
    "Сістэмны ўстаноўшчык Android (па змаўчанні)",
    "Default Android system package installer",
    "Android-System-Paketinstaller (Standard)"
  ],
  "Свой установщик": ["Власний встановлювач", "Свой устаноўшчык", "Custom installer", "Eigener Installer"],
  "Указать Package Name установщика вручную": [
    "Вказати Package Name встановлювача вручну",
    "Указаць Package Name устаноўшчыка ўручную",
    "Specify custom installer Package Name manually",
    "Paketnamen des Installers manuell eingeben"
  ],
  "Выберите приложение для установки APK. При сбоях или отсутствии выбранного установщика автоматически сработает системный.": [
    "Виберіть програму для встановлення APK. У разі збою або відсутності вибраного встановлювача автоматично спрацює системний.",
    "Выберыце праграму для ўстаноўкі APK. Пры збоях або адсутнасці выбранага ўстаноўшчыка аўтаматычна спрацуе сістэмны.",
    "Choose an app to install APKs. Automatically falls back to the system installer if unavailable.",
    "Wählen Sie eine App für die APK-Installation. Bei Fehlern wird automatisch der System-Installer verwendet."
  ],
  "Package Name приложения:": ["Package Name програми:", "Package Name праграмы:", "App Package Name:", "App-Paketname:"],
  "например, com.rosan.installer.x.revived": ["наприклад, com.rosan.installer.x.revived", "напрыклад, com.rosan.installer.x.revived", "e.g., com.rosan.installer.x.revived", "z. B. com.rosan.installer.x.revived"],
  "Отображать файлы только под мой процессор": [
    "Відображати файли лише під мій процесор",
    "Паказваць файлы толькі пад мой працэсар",
    "Show only files matching my device CPU",
    "Nur Dateien für meinen Prozessor anzeigen"
  ],
  "Каталог приложений 4pda (подстрочный поиск)": [
    "Каталог програм 4pda (підрядковий пошук)",
    "Каталог праграм 4pda (падрядковы пошук)",
    "4PDA app catalog (substring search)",
    "4PDA-App-Katalog (Teilwortsuche)"
  ],
  "База названий 4pda собирается на GitHub, хранится локально; при запуске приложение лишь сверяет версию и догружает изменения. Кнопка — синхронизировать/перекачать сейчас.": [
    "База назв 4pda збирається на GitHub, зберігається локально; під час запуску програма лише звіряє версію і довантажує зміни. Кнопка — синхронізувати/перекачати зараз.",
    "База назваў 4pda збіраецца на GitHub, захоўваецца лакальна; пры запуску праграма толькі звярае версію і дагружае змены. Кнопка — сінхранізаваць/перапампаваць зараз.",
    "The 4PDA title database is built on GitHub and cached locally; on startup the app checks for updates. Use the button to force sync now.",
    "Die 4PDA-Datenbank wird auf GitHub erstellt und lokal gespeichert. Beim Start prüft die App auf Änderungen. Tippen zum Synchronisieren."
  ],
  "Обновить каталог": ["Оновити каталог", "Абнавіць каталог", "Update catalog", "Katalog aktualisieren"],
  "Качаю…": ["Завантажую…", "Пампую…", "Downloading…", "Lade herunter…"],
  "Качаю каталог с GitHub…": ["Завантажую каталог з GitHub…", "Пампую каталог з GitHub…", "Downloading catalog from GitHub…", "Lade Katalog von GitHub…"],
  "Не удалось скачать (проверь, что catalog.json собрался в репозитории)": [
    "Не вдалося завантажити (перевір, чи catalog.json зібрався в репозиторії)",
    "Не ўдалося спампаваць (правер, ці catalog.json сабраўся ў рэпазіторыі)",
    "Download failed (check that catalog.json exists in repository)",
    "Download fehlgeschlagen (prüfen Sie catalog.json im Repository)"
  ],
  "В каталоге:": ["У каталозі:", "У каталогу:", "In catalog:", "Im Katalog:"],
  "тем": ["тем", "тэм", "topics", "Themen"],

  // Backup / Save Settings
  "Сохранение настроек": ["Збереження налаштувань", "Захаванне налад", "Backup & Restore", "Sichern & Wiederherstellen"],
  "Файл со всеми пометками и настройками: избранное, скрытые приложения и обновления, тема, разделы, папка загрузки, вид списка.": [
    "Файл з усіма позначками та налаштуваннями: обране, приховані програми та оновлення, тема, розділи, папка завантаження, вигляд списку.",
    "Файл з усімі пазнакамі і наладамі: абранае, схаваныя праграмы і абнаўленні, тэма, раздзелы, папка спампоўкі, выгляд спісу.",
    "Backup file with all tags and preferences: favorites, hidden apps/updates, theme, sections, download folder, layout.",
    "Sicherungsdatei mit allen Markierungen und Einstellungen: Favoriten, ausgeblendete Apps/Updates, Design, Bereiche, Download-Ordner."
  ],
  "Что сохранить": ["Що зберегти", "Што захаваць", "Items to export", "Zu sichernde Elemente"],
  "Что восстановить": ["Що відновити", "Што аднавіць", "Items to restore", "Wiederherzustellende Elemente"],
  "Скрытые обновления": ["Приховані оновлення", "Схаваныя абнаўленні", "Hidden updates", "Ausgeblendete Updates"],
  "Скрытые приложения": ["Приховані програми", "Схаваныя праграмы", "Hidden apps", "Ausgeblendete Apps"],
  "Настройки приложения": ["Налаштування програми", "Налады праграмы", "App preferences", "App-Einstellungen"],
  "Сохранить в файл": ["Зберегти у файл", "Захаваць у файл", "Save to file", "In Datei speichern"],
  "Вставить файл": ["Вставити файл", "Уставіць файл", "Paste backup content", "Dateiinhalt einfügen"],
  "Файл появится в папке «Загрузки».": ["Файл з'явиться в папці «Завантаження».", "Файл з'явіцца ў папцы «Спампоўкі».", "The file will be saved to your Downloads folder.", "Die Datei wird im Ordner „Downloads“ gespeichert."],
  "Откройте сохранённый файл и вставьте его содержимое.": [
    "Відкрийте збережений файл і вставте його вміст.",
    "Адкрыйце захаваны файл і ўстаўце яго змесціва.",
    "Open the backup file and paste its contents.",
    "Öffnen Sie die gespeicherte Datei und fügen Sie deren Inhalt ein."
  ],
  "Восстановить настройки": ["Відновити налаштування", "Аднавіць налады", "Restore settings", "Einstellungen wiederherstellen"],
  "Вставьте содержимое сохранённого файла.": ["Вставте вміст збереженого файлу.", "Устаўце змесціва захаванага файла.", "Paste the contents of the backup file.", "Fügen Sie den Inhalt der Sicherungsdatei ein."],
  "Файл не распознан": ["Файл не розпізнано", "Файл не распазнаны", "Unrecognized backup file", "Datei nicht erkannt"],
  "Импорт связей": ["Імпорт зв'язків", "Імпарт сувязяў", "Import topic links", "Verknüpfungen importieren"],
  "Вставьте содержимое файла экспорта": ["Вставте вміст файлу експорту", "Устаўце змесціва файла экспарту", "Paste export file content", "Inhalt der Exportdatei einfügen"],
  "Импортировать": ["Імпортувати", "Імпартаваць", "Import", "Importieren"],
  "Не похоже на файл экспорта": ["Не схоже на файл експорту", "Не падобна на файл экспарту", "Invalid export file format", "Ungültiges Exportdateiformat"],

  // Debug Screen
  "Отладка": ["Налагодження", "Адладка", "Debug", "Diagnose"],
  "Пробник протокола 4pda": ["Пробник протоколу 4pda", "Пробнік пратакола 4pda", "4PDA protocol probe", "4PDA-Protokoll-Tester"],
  "сервер": ["сервер", "сервер", "server", "Server"],
  "порт": ["порт", "порт", "port", "Port"],
  "Защищённое соединение": ["Захищене з'єднання", "Абароненае злучэнне", "TLS connection", "Sichere Verbindung (TLS)"],
  "Тип пакета": ["Тип пакета", "Тып пакета", "Packet type", "Pakettyp"],
  "со сжатием": ["зі стисненням", "са сцісканнем", "compressed", "komprimiert"],
  "без сжатия": ["без стиснення", "без сціскання", "uncompressed", "unkomprimiert"],
  "что отправить: текст или байты вида 5b 74 71 5d": [
    "що відправити: текст або байти виду 5b 74 71 5d",
    "што адправіць: тэкст або байты выгляду 5b 74 71 5d",
    "payload: text or hex bytes like 5b 74 71 5d",
    "Sendedaten: Text oder Hex-Bytes wie 5b 74 71 5d"
  ],
  "Жду…": ["Чекаю…", "Чакаю…", "Waiting…", "Warte…"],
  "Жду ответ…": ["Чекаю відповідь…", "Чакаю адказ…", "Waiting for reply…", "Warte auf Antwort…"],
  "Профиль": ["Профіль", "Профіль", "Profile", "Profil"],
  "Файлы темы": ["Файли теми", "Файлы тэмы", "Topic files", "Themendateien"],
  "Разметка шапки": ["Розмітка шапки", "Разметка шапкі", "Header markup", "Kopfzeilen-HTML"],
  "Поиск App&Game": ["Пошук App&Game", "Пошук App&Game", "App&Game search", "App&Game-Suche"],
  "Режимы поиска": ["Режими пошуку", "Рэжымы пошуку", "Search modes", "Suchmodi"],
  "Спросить App&Game": ["Запитати App&Game", "Спытаць App&Game", "Query App&Game", "App&Game abfragen"],
  "Ссылка на файл": ["Посилання на файл", "Спасылка на файл", "File link", "Dateilink"],
  "Спросить тему": ["Запитати тему", "Спытаць тэму", "Query topic", "Thema abfragen"],
  "Подключиться и отправить": ["Підключитися і відправити", "Падключыцца і адправіць", "Connect & send", "Verbinden & senden"],
  "Отправить как клиент": ["Відправити як клієнт", "Адправіць як кліент", "Send as client", "Als Client senden"],
  "Отправить": ["Відправити", "Адправіць", "Send", "Senden"],
  "Скопировать ответ": ["Скопіювати відповідь", "Скапіяваць адказ", "Copy response", "Antwort kopieren"],
  "Диагностика (плашка со служебной информацией)": [
    "Діагностика (плашка зі службовою інформацією)",
    "Дыягностыка (плашка са службовай інфармацыяй)",
    "Diagnostics overlay (status bar)",
    "Diagnose-Leiste (Statusinformationen)"
  ],
  "Скопировать отладку": ["Скопіювати налагодження", "Скапіяваць адладку", "Copy debug log", "Debug-Log kopieren"],
  "Сохранить всё": ["Зберегти все", "Захаваць усё", "Save all", "Alles speichern"],
  "ОТЛАДКА ПОИСКА": ["НАЛАГОДЖЕННЯ ПОШУКУ", "АДЛАДКА ПОШУКУ", "SEARCH DEBUG", "SUCH-DIAGNOSE"],
  "Отладка скопирована": ["Налагодження скопійовано", "Адладка скапіявана", "Debug log copied", "Diagnose kopiert"],
  "Диагностика скопирована": ["Діагностику скопійовано", "Дыягностыка скапіявана", "Diagnostics copied", "Diagnose kopiert"],
  "Подключаюсь…": ["Підключаюся…", "Падключаюся…", "Connecting…", "Verbinde…"],
  "Спрашиваю тему у сервера приложения…": ["Запитую тему у сервера програми…", "Пытаю тэму ў сервера праграмы…", "Querying topic from app server…", "Frage Thema vom App-Server ab…"],
  "Спрашиваю профиль…": ["Запитую профіль…", "Пытаю профіль…", "Querying profile…", "Frage Profil ab…"],
  "Спрашиваю файлы темы…": ["Запитую файли теми…", "Пытаю файлы тэмы…", "Querying topic files…", "Frage Themendateien ab…"],
  "Читаю шапку темы…": ["Читаю шапку теми…", "Чытаю шапку тэмы…", "Reading topic header…", "Lese Themen-Kopfzeile…"],
  "Пробую поиск на сервере App&Game…": ["Пробую пошук на сервері App&Game…", "Спрабую пошук на серверы App&Game…", "Testing search on App&Game server…", "Teste Suche auf App&Game-Server…"],
  "Пробую разные режимы поиска…": ["Пробую різні режими пошуку…", "Спрабую розныя рэжымы пошуку…", "Testing search modes…", "Teste Suchmodi…"],
  "Спрашиваю сервер App&Game…": ["Запитую сервер App&Game…", "Пытаю сервер App&Game…", "Querying App&Game server…", "Frage App&Game-Server ab…"],
  "Спрашиваю ссылку на файл…": ["Запитую посилання на файл…", "Пытаю спасылку на файл…", "Requesting file link…", "Frage Dateilink an…"],
  "Впиши в поле номер вложения (число)": ["Впиши в поле номер вкладення (число)", "Упішы ў поле нумар укладання (лік)", "Enter attachment ID (number) in the field", "Anhangs-ID (Zahl) in das Feld eingeben"],
  "Здороваюсь с сервером…": ["Вітаюся з сервером…", "Вітаюся з серверам…", "Handshaking with server…", "Handshake mit Server…"],
  "Отправляю пакет…": ["Відправляю пакет…", "Адпраўляю пакет…", "Sending packet…", "Sende Paket…"],
  "Тапни, чтобы закрыть, и пришли этот текст.": ["Торкнись, щоб закрити, і надішли цей текст.", "Дакраніся, каб закрыць, і дашлі гэты тэкст.", "Tap to close and share this error text.", "Zum Schließen tippen und diesen Text senden."],
  "Не удалось экспортировать авторизацию": ["Не вдалося експортувати авторизацію", "Не ўдалося экспартаваць аўтарызацыю", "Failed to export auth cookies", "Autorisierungsexport fehlgeschlagen"],
  "тема": ["тема", "тэма", "topic", "Thema"],
  "файл": ["файл", "файл", "file", "Datei"],

  // Units
  "МБ": ["МБ", "МБ", "MB", "MB"],
  "КБ": ["КБ", "КБ", "KB", "KB"],
  "МБ/с": ["МБ/с", "МБ/с", "MB/s", "MB/s"],
  "КБ/с": ["КБ/с", "КБ/с", "KB/s", "KB/s"],
};

const LANG_IDX = { uk: 0, be: 1, en: 2, de: 3 };

function replaceUnits(s, idx) {
  if (idx < 2) return s; // uk and be keep МБ/КБ
  return s
    .replace(/(\d)\s*МБ\/с/g, "$1 MB/s")
    .replace(/(\d)\s*КБ\/с/g, "$1 KB/s")
    .replace(/(\d)\s*МБ/g, "$1 MB")
    .replace(/(\d)\s*КБ/g, "$1 KB");
}

export function tr(str, langOverride) {
  if (!str || typeof str !== "string") return str;
  const lang = langOverride || getLang();
  if (lang === "ru") return str;
  const idx = LANG_IDX[lang];
  if (idx === undefined) return str;

  const m = str.match(/^(\s*)([\s\S]*?)(\s*)$/);
  if (!m) return str;
  const [, lead, core, trail] = m;
  if (!core) return str;

  // 1. Direct lookup
  if (PHRASES[core]) {
    return lead + PHRASES[core][idx] + trail;
  }

  // 2. Dynamic pattern matching
  // "Выбрано: 5"
  let pm = core.match(/^Выбрано:\s*(\d+)$/);
  if (pm) {
    const p = ["Вибрано: ", "Выбрана: ", "Selected: ", "Ausgewählt: "][idx];
    return lead + p + pm[1] + trail;
  }

  // "Показать ещё (42)"
  pm = core.match(/^Показать ещё \((\d+)\)$/);
  if (pm) {
    const p = ["Показати ще (", "Паказаць яшчэ (", "Show more (", "Mehr anzeigen ("][idx];
    return lead + p + pm[1] + ")" + trail;
  }

  // "Осталось 12 сек · 1.50 МБ/с"
  pm = core.match(/^Осталось\s+(\d+)\s+сек\s*·\s*(.+)$/);
  if (pm) {
    const sp = replaceUnits(pm[2], idx);
    const out = [
      `Залишилось ${pm[1]} сек · ${sp}`,
      `Засталося ${pm[1]} сек · ${sp}`,
      `${pm[1]}s left · ${sp}`,
      `Noch ${pm[1]} Sek. · ${sp}`,
    ][idx];
    return lead + out + trail;
  }

  // "Готово: 12345 тем в каталоге"
  pm = core.match(/^Готово:\s*(\d+)\s*тем в каталоге$/);
  if (pm) {
    const out = [
      `Готово: ${pm[1]} тем у каталозі`,
      `Гатова: ${pm[1]} тэм у каталогу`,
      `Done: ${pm[1]} topics in catalog`,
      `Fertig: ${pm[1]} Themen im Katalog`,
    ][idx];
    return lead + out + trail;
  }

  // "В каталоге: 12345 тем"
  pm = core.match(/^В каталоге:\s*(\d+)\s*тем$/);
  if (pm) {
    const out = [
      `У каталозі: ${pm[1]} тем`,
      `У каталогу: ${pm[1]} тэм`,
      `In catalog: ${pm[1]} topics`,
      `Im Katalog: ${pm[1]} Themen`,
    ][idx];
    return lead + out + trail;
  }

  // "Свой (com.pkg)"
  pm = core.match(/^Свой\s*\((.+)\)$/);
  if (pm) {
    const p = ["Власний (", "Свой (", "Custom (", "Eigener ("][idx];
    return lead + p + pm[1] + ")" + trail;
  }

  // "сборка 09.08-IC6"
  pm = core.match(/^сборка\s+(.+)$/);
  if (pm) {
    const p = ["збірка ", "зборка ", "build ", "Build "][idx];
    return lead + p + pm[1] + trail;
  }

  // "Поиск: Программы · Enter"
  pm = core.match(/^Поиск:\s*(.+?)\s*·\s*Enter$/);
  if (pm) {
    const cat = tr(pm[1], lang);
    const p = ["Пошук: ", "Пошук: ", "Search: ", "Suche: "][idx];
    return lead + `${p}${cat} · Enter` + trail;
  }

  // "Поиск на сайте : 45"
  pm = core.match(/^Поиск на сайте\s*:\s*(\d+)$/);
  if (pm) {
    const p = ["Пошук на сайті : ", "Пошук на сайце : ", "Site search : ", "Website-Suche : "][idx];
    return lead + p + pm[1] + trail;
  }

  // "Обновление: 12.05.2026"
  pm = core.match(/^Обновление:\s*(.+)$/);
  if (pm) {
    const p = ["Оновлення: ", "Абнаўленне: ", "Updated: ", "Aktualisiert: "][idx];
    return lead + p + pm[1] + trail;
  }

  // "Связано: ..."
  pm = core.match(/^Связано:\s*(.+)$/);
  if (pm) {
    const p = ["Пов'язано: ", "Звязана: ", "Linked: ", "Verknüpft: "][idx];
    return lead + p + pm[1] + trail;
  }

  // "Сохранено: ..."
  pm = core.match(/^Сохранено:\s*(.+)$/);
  if (pm) {
    const p = ["Збережено: ", "Захавана: ", "Saved: ", "Gespeichert: "][idx];
    return lead + p + pm[1] + trail;
  }

  // "Восстановлено: N пометок"
  pm = core.match(/^Восстановлено:\s*(\d+)\s*пометок$/);
  if (pm) {
    const out = [
      `Відновлено: ${pm[1]} позначок`,
      `Адноўлена: ${pm[1]} пазнак`,
      `Restored: ${pm[1]} items`,
      `Wiederhergestellt: ${pm[1]} Einträge`,
    ][idx];
    return lead + out + trail;
  }

  // "Импортировано связей: N"
  pm = core.match(/^Импортировано связей:\s*(\d+)$/);
  if (pm) {
    const out = [
      `Імпортовано зв'язків: ${pm[1]}`,
      `Імпартавана сувязяў: ${pm[1]}`,
      `Imported links: ${pm[1]}`,
      `Verknüpfungen importiert: ${pm[1]}`,
    ][idx];
    return lead + out + trail;
  }

  // "Не удалось загрузить: ..."
  pm = core.match(/^Не удалось загрузить:\s*(.+)$/);
  if (pm) {
    const p = ["Не вдалося завантажити: ", "Не ўдалося загрузіць: ", "Failed to load: ", "Laden fehlgeschlagen: "][idx];
    return lead + p + pm[1] + trail;
  }

  // "Не удалось установить: ..."
  pm = core.match(/^Не удалось установить:\s*(.+)$/);
  if (pm) {
    const p = ["Не вдалося встановити: ", "Не ўдалося ўсталяваць: ", "Failed to install: ", "Installation fehlgeschlagen: "][idx];
    return lead + p + pm[1] + trail;
  }

  // "Установка не выполнена: ..."
  pm = core.match(/^Установка не выполнена:\s*([\s\S]+)$/);
  if (pm) {
    const p = ["Встановлення не виконано: ", "Устаноўка не выканана: ", "Installation failed: ", "Installation fehlgeschlagen: "][idx];
    return lead + p + pm[1] + trail;
  }

  // "Ошибка: ..."
  pm = core.match(/^Ошибка:\s*(.+)$/);
  if (pm) {
    const p = ["Помилка: ", "Памылка: ", "Error: ", "Fehler: "][idx];
    return lead + p + pm[1] + trail;
  }

  // "Это отдельное приложение (X), у вас оно не установлено — подпись сравнивать не с чем."
  pm = core.match(/^Это отдельное приложение \((.+?)\), у вас оно не установлено — подпись сравнивать не с чем\.$/);
  if (pm) {
    const out = [
      `Це окрема програма (${pm[1]}), у вас вона не встановлена — підпис немає з чим порівнювати.`,
      `Гэта асобная праграма (${pm[1]}), у вас яна не ўсталявана — подпіс няма з чым параўноўваць.`,
      `This is a separate app (${pm[1]}) not installed on your device — no signature to compare.`,
      `Dies ist eine separate App (${pm[1]}), die nicht installiert ist — kein Signaturvergleich möglich.`,
    ][idx];
    return lead + out + trail;
  }

  // "Скачиваний: X · Добавлено: Y" or "Скачиваний: X" or "Добавлено: Y"
  if (/^(?:Скачиваний:\s*\d+|Добавлено:\s*.+)/.test(core)) {
    const dlLbl = ["Завантажень: ", "Спамповак: ", "Downloads: ", "Downloads: "][idx];
    const addLbl = ["Додано: ", "Дададзена: ", "Added: ", "Hinzugefügt: "][idx];
    const replaced = core
      .replace(/Скачиваний:\s*/g, dlLbl)
      .replace(/Добавлено:\s*/g, addLbl);
    return lead + replaced + trail;
  }

  // "· Скачиваний: X"
  if (core.includes("· Скачиваний:")) {
    const dlLbl = ["· Завантажень:", "· Спамповак:", "· Downloads:", "· Downloads:"][idx];
    return lead + core.replace("· Скачиваний:", dlLbl) + trail;
  }

  // "тема 12345" or "... · тема 12345"
  pm = core.match(/^(.*?)\bтема\s+(\d{4,9})$/);
  if (pm) {
    const tWord = ["тема ", "тэма ", "topic ", "Thema "][idx];
    const prefix = pm[1] ? tr(pm[1], lang) : "";
    return lead + prefix + tWord + pm[2] + trail;
  }

  // Numbers with МБ / КБ / МБ/с / КБ/с
  if (/^\d+(?:[.,]\d+)?\s*(?:МБ|КБ)(?:\/с)?(?:\s*\/\s*\d+(?:[.,]\d+)?\s*(?:МБ|КБ))?$/.test(core)) {
    return lead + replaceUnits(core, idx) + trail;
  }

  return str;
}

function shouldSkipElement(el) {
  if (!el || !el.closest) return false;
  // Do not translate 4PDA forum post HTML body
  return !!el.closest(".topic-desc");
}

function translateTextNode(node, lang) {
  try {
    if (!node || node.nodeType !== 3) return;
    if (shouldSkipElement(node.parentElement)) return;
    const cur = node.nodeValue;
    if (!cur || !cur.trim()) return;
    if (node.__t4orig === undefined || cur !== node.__t4last) {
      node.__t4orig = cur;
    }
    const next = tr(node.__t4orig, lang);
    node.__t4last = next;
    if (cur !== next) {
      node.nodeValue = next;
    }
  } catch {}
}

function translateElementAttrs(el, lang) {
  try {
    if (!el || el.nodeType !== 1) return;
    if (shouldSkipElement(el)) return;
    for (const attr of ["placeholder", "title"]) {
      if (el.hasAttribute(attr)) {
        const cur = el.getAttribute(attr);
        const origKey = "__t4orig_" + attr;
        const lastKey = "__t4last_" + attr;
        if (el[origKey] === undefined || cur !== el[lastKey]) {
          el[origKey] = cur;
        }
        const next = tr(el[origKey], lang);
        el[lastKey] = next;
        if (cur !== next) {
          el.setAttribute(attr, next);
        }
      }
    }
  } catch {}
}

export function applyLangToDOM(root, langOverride) {
  try {
    const lang = langOverride || getLang();
    const target = root || document.body;
    if (!target) return;
    if (target.nodeType === 3) {
      translateTextNode(target, lang);
      return;
    }
    if (target.nodeType === 1) {
      translateElementAttrs(target, lang);
    }
    const walker = document.createTreeWalker(target, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
    let n = walker.nextNode();
    while (n) {
      if (n.nodeType === 3) translateTextNode(n, lang);
      else if (n.nodeType === 1) translateElementAttrs(n, lang);
      n = walker.nextNode();
    }
  } catch {}
}

let _observerInstalled = false;
export function installDomTranslator() {
  if (_observerInstalled || typeof window === "undefined" || typeof MutationObserver === "undefined") return;
  _observerInstalled = true;
  try {
    const obs = new MutationObserver((mutations) => {
      const lang = getLang();
      for (const m of mutations) {
        if (m.type === "characterData") {
          translateTextNode(m.target, lang);
        } else if (m.type === "attributes") {
          translateElementAttrs(m.target, lang);
        } else if (m.type === "childList") {
          for (const added of m.addedNodes) {
            if (added.nodeType === 3) translateTextNode(added, lang);
            else if (added.nodeType === 1) applyLangToDOM(added, lang);
          }
        }
      }
    });
    const start = () => {
      if (!document.body) return;
      applyLangToDOM(document.body);
      obs.observe(document.body, {
        childList: true,
        subtree: true,
        characterData: true,
        attributes: true,
        attributeFilter: ["placeholder", "title"],
      });
    };
    if (document.body) start();
    else window.addEventListener("DOMContentLoaded", start, { once: true });
  } catch {}
}
